package org.example;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class RadioButtonsTest {
    public static void main(String[] args) {
        // Configura el WebDriver para Chrome
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();

        // Navega a la página
        driver.get("https://www.ironspider.ca/forms/checkradio.htm#checkbox");
        driver.manage().window().maximize();

        // Localiza todos los radio buttons
        WebElement redColor = driver.findElement(By.xpath("//input[@value='red']"));
        WebElement yellowColor = driver.findElement(By.xpath("//input[@value='yellow']"));
        WebElement blueColor = driver.findElement(By.xpath("//input[@value='blue']"));
        WebElement orangeColor = driver.findElement(By.xpath("//input[@value='orange']"));
        WebElement purpleColor = driver.findElement(By.xpath("//input[@value='purple']"));
        WebElement greenColor = driver.findElement(By.xpath("//input[@value='green']"));

        // Imprime el valor de isSelected() para todos los botones
        System.out.println("Valor redColor: " + redColor.isSelected());
        System.out.println("Valor yellowColor: " + yellowColor.isSelected());
        System.out.println("Valor blueColor: " + blueColor.isSelected());
        System.out.println("Valor orangeColor: " + orangeColor.isSelected());
        System.out.println("Valor purpleColor: " + purpleColor.isSelected());
        System.out.println("Valor greenColor: " + greenColor.isSelected());

        // Hace click en los botones Yellow, Orange y Purple
        yellowColor.click();
        orangeColor.click();
        purpleColor.click();

        // Imprime los valores de isSelected() luego de hacer clic
        System.out.println("========== Luego de hacer click ============");
        System.out.println("Valor redColor: " + redColor.isSelected());
        System.out.println("Valor yellowColor: " + yellowColor.isSelected());
        System.out.println("Valor blueColor: " + blueColor.isSelected());
        System.out.println("Valor orangeColor: " + orangeColor.isSelected());
        System.out.println("Valor purpleColor: " + purpleColor.isSelected());
        System.out.println("Valor greenColor: " + greenColor.isSelected());

        // Cierra el navegador
        driver.quit();
    }
}

