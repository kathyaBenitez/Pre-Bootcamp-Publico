package org.example;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import io.github.bonigarcia.wdm.WebDriverManager;

import java.time.Duration;

public class InteractuarConCamposDeTexto {
    WebDriver driver;

    @BeforeMethod
    public void configurarDriver() {
        WebDriverManager.chromedriver().setup();

        ChromeOptions options = new ChromeOptions();
        options.addArguments("--remote-allow-origins=*");
        driver = new ChromeDriver(options);

        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
    }

    @Test
    public void chromeTest() {
        driver.get("https://magento.softwaretestingboard.com/customer/account/login/");

        // Localizar el campo de búsqueda
        WebElement searchInput = driver.findElement(By.id("search"));

        // Interacciones con el campo de texto
        searchInput.sendKeys("shirt");
        searchInput.clear();
        searchInput.sendKeys("trousers");

        // Imprimir todos los atributos del campo de texto
        System.out.println("Atributo id: " + searchInput.getAttribute("id"));
        System.out.println("Atributo type: " + searchInput.getAttribute("type"));
        System.out.println("Atributo name: " + searchInput.getAttribute("name"));
        System.out.println("Atributo value: " + searchInput.getAttribute("value"));
        System.out.println("Atributo placeholder: " + searchInput.getAttribute("placeholder"));
        System.out.println("Atributo class: " + searchInput.getAttribute("class"));
        System.out.println("Atributo maxlength: " + searchInput.getAttribute("maxlength"));
        System.out.println("Atributo role: " + searchInput.getAttribute("role"));
        System.out.println("Atributo aria-haspopup: " + searchInput.getAttribute("aria-haspopup"));
        System.out.println("Atributo aria-autocomplete: " + searchInput.getAttribute("aria-autocomplete"));
        System.out.println("Atributo autocomplete: " + searchInput.getAttribute("autocomplete"));
        System.out.println("Atributo aria-expanded: " + searchInput.getAttribute("aria-expanded"));
    }

    @AfterMethod
    public void limpiarDriver() {
        if (driver != null) {
            driver.quit();
        }
    }
}
