package org.example;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import io.github.bonigarcia.wdm.WebDriverManager;

import java.time.Duration;

public class SelectDropdownTest {
    WebDriver driver;

    @BeforeMethod
    public void configurarDriver() {
        WebDriverManager.chromedriver().setup();

        ChromeOptions options = new ChromeOptions();
        options.addArguments("--remote-allow-origins=*");
        driver = new ChromeDriver(options);

        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
    }

    @Test
    public void selectTest() {
        driver.get("https://qa-practice.netlify.app/dropdowns");

        // Localizar el elemento Select por id
        WebElement selectElement = driver.findElement(By.id("dropdown-menu"));

        // Crear un objeto Select para interactuar con el elemento
        Select select = new Select(selectElement);

        // Seleccionar opciones del dropdown
        select.selectByIndex(2); // Seleccionar Albania
        System.out.println("Opción seleccionada por índice: " + select.getFirstSelectedOption().getText());

        select.selectByValue("Monaco"); // Seleccionar Monaco
        System.out.println("Opción seleccionada por valor: " + select.getFirstSelectedOption().getText());

        select.selectByVisibleText("Uruguay"); // Seleccionar Uruguay
        System.out.println("Opción seleccionada por texto visible: " + select.getFirstSelectedOption().getText());
    }

    @AfterMethod
    public void limpiarDriver() {
        if (driver != null) {
            driver.quit();
        }
    }
}
