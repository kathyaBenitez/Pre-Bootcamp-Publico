package org.example;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class PracticeAdvancedXpath {
    public static void main(String[] args) {
        // Configura el WebDriver para Chrome
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();

        // Navega a la página
        driver.get("https://the-internet.herokuapp.com/add_remove_elements/");

        // Maximiza la ventana del navegador
        driver.manage().window().maximize();

        // Localiza el h3 usando la función substring() en XPath
        WebElement addRemoveElement = driver.findElement(By.xpath("//h3[substring(text(), 1, 10)='Add/Remove']"));

        // Imprime el texto del elemento encontrado
        System.out.println(addRemoveElement.getText());

        // Cierra el navegador
        driver.close();
    }
}


