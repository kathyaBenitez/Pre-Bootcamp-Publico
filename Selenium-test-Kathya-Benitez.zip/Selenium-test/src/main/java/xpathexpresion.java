import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
public class xpathexpresion {
    public static void main(String[] args) throws Exception {
        WebDriver driver = common.Configuration.createGeckoDriver();
        driver.get("https://automationexercise.com");
        driver.manage().window().maximize();
        try{
            // Agregar el primer producto
            WebElement primerProducto = driver.findElement(By.xpath("//a[@data-product-id='1' and contains(@class, 'add-to-cart')]"));
            primerProducto.click();
            Thread.sleep(2000);
            // Ir al carrito
            WebElement verCarrito = driver.findElement(By.xpath("//u[normalize-space()='View Cart']"));
            verCarrito.click();
            Thread.sleep(2000);
            // Busca el precio del producto en el carrito
            WebElement precioProducto = driver.findElement(By.xpath("//tr[@id='product-1']//td[@class='cart_price']/p"));
            Thread.sleep(2000);
            // Verifica que el precio sea el correcto
            String precioEsperado = "Rs. 500";
            String precioConseguido = precioProducto.getText();
            System.out.println("Esperado:" + precioEsperado);
            System.out.println("Conseguido:" + precioConseguido);
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            driver.quit();
        }

    }

}