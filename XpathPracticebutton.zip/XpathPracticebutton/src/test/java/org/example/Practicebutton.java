package org.example;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Practicebutton {
    WebDriver driver;

    @BeforeMethod
    public void configurarDriver() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
    }

    @Test
    public void chromeTest() {
        // Navegar a la página
        driver.get("https://katalon-demo-cura.herokuapp.com/");

        // Localizar el botón Make an appointment usando contains()
        WebElement buttonElement = driver.findElement(By.xpath("//a[contains(@id,'btn-make-appointment')]"));

        // Hacer clic en el botón
        buttonElement.click();

        // Validar si la página cambia o el botón se presiona correctamente (opcional)
        System.out.println("Botón 'Make an appointment' presionado correctamente.");
    }

    @AfterMethod
    public void cerrarDriver() {
        if (driver != null) {
            driver.quit();
        }
    }
}
