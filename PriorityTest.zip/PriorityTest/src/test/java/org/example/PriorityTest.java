package org.example;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
public class PriorityTest {
    static WebDriver driver;
    @BeforeMethod
    public void configurarDriver() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
        driver.get("https://qa-practice.netlify.app/auth_ecommerce");
    }

    @Test(priority = 1)
    public void loginCorrecto() {
        WebElement emailInput = driver.findElement(By.id("email"));
        emailInput.sendKeys("admin@admin.com");

        WebElement passwordInput = driver.findElement(By.id("password"));
        passwordInput.sendKeys("admin123");

        WebElement submitButton = driver.findElement(By.id("submitLoginBtn"));
        submitButton.click();

    }
    @Test()
    public void loginInvalido() {
        WebElement emailInput = driver.findElement(By.id("email"));
        emailInput.sendKeys("invaliduser@admin.com");

        WebElement passwordInput = driver.findElement(By.id("password"));
        passwordInput.sendKeys("invalid123");

        WebElement submitButton = driver.findElement(By.id("submitLoginBtn"));
        submitButton.click();

        WebElement errorMessage = driver.findElement(By.id("message"));
        String errorMessageText = errorMessage.getText();

        System.out.println(errorMessageText);
    }

    @AfterMethod
    public void limpiarMetodo() {
        driver.close();
    }
}