package org.example;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import io.github.bonigarcia.wdm.WebDriverManager;

public class pruebaxpath {
    WebDriver driver;

    @BeforeMethod
    public void configurarDriver() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
    }

    @Test
    public void chromeTest() {
        // Navegar a la página de login
        driver.get("https://the-internet.herokuapp.com/login");

        // Ingresar el usuario utilizando XPath
        WebElement usernameField = driver.findElement(By.xpath("//input[@id='username']"));
        usernameField.sendKeys("tomsmith");

        // Ingresar la contraseña utilizando XPath
        WebElement passwordField = driver.findElement(By.xpath("//input[@id='password']"));
        passwordField.sendKeys("SuperSecretPassword!");

        // Hacer clic en el botón de login
        WebElement loginButton = driver.findElement(By.xpath("//button[@type='submit']"));
        loginButton.click();

        // Validar si el login fue exitoso (opcional)
        WebElement successMessage = driver.findElement(By.xpath("//div[@class='flash success']"));
        if (successMessage.isDisplayed()) {
            System.out.println("Login exitoso: " + successMessage.getText());
        } else {
            System.out.println("Login fallido.");
        }
    }

    @AfterMethod
    public void cerrarDriver() {
        if (driver != null) {
            driver.quit();
        }
    }
}
