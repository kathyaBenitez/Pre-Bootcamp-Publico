package org.example;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import io.github.bonigarcia.wdm.WebDriverManager;

public class CombinandoAtributosTest{
    WebDriver driver;

    @BeforeMethod
    public void configurarDriver() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
    }

    @Test
    public void chromeTest() {
        // Navegar a la página
        driver.get("http://uitestingplayground.com/textinput");

        // Localizar el input utilizando XPath y 'and'
        WebElement inputElement = driver.findElement(By.xpath("//input[@class='form-control' and @id='newButtonName']"));

        // Ingresar texto en el input
        inputElement.sendKeys("texto");

        // Localizar el botón utilizando XPath y 'and'
        WebElement buttonElement = driver.findElement(By.xpath("//button[@class='btn btn-primary' and @id='updatingButton']"));

        // Hacer clic en el botón
        buttonElement.click();

        // Mensaje de validación en la consola
        System.out.println("Texto ingresado y botón clickeado correctamente.");
    }

    @AfterMethod
    public void cerrarDriver() {
        if (driver != null) {
            driver.quit();
        }
    }
}
